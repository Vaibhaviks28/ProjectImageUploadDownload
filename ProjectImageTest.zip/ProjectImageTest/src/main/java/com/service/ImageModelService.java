package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.model.ImageModel;

public interface ImageModelService {
	
	public ImageModel storeFile(MultipartFile multipart);
	
	public Optional<ImageModel> getFile(Long fileId);
    public List<ImageModel> getAllFile( );

}
