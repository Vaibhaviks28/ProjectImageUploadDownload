package com.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.dao.ImageModelRepository;
import com.model.ImageModel;

@Service

public class ImageModelServiceImpl implements ImageModelService {

	@Autowired
	private ImageModelRepository imageRepository;
	
	
	@Override
	public ImageModel storeFile(MultipartFile file) {
		ImageModel img =new ImageModel();
		img.setName(file.getOriginalFilename());
		try {
			img.setImageData(file.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return imageRepository.save(img);
	}
	
	 @Override
	    public Optional<ImageModel> getFile(Long fileId) {
	        
	         return imageRepository.findById(fileId);
	    }

	    @Override
	    public List<ImageModel> getAllFile() {
	        
	         return imageRepository.findAll();
	    }

}
