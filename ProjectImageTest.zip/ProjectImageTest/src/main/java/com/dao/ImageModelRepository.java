package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.ImageModel;

public interface ImageModelRepository extends JpaRepository<ImageModel,Long> {

}
